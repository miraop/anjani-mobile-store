import React, { useState } from 'react';
import { IntroExperience } from './components/IntroExperience';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { CategorySection } from './components/CategorySection';
import { FeaturedShowcase } from './components/FeaturedShowcase';
import { PhoneValuationCalculator } from './components/PhoneValuationCalculator';
import { AutoGallery } from './components/AutoGallery';
import { ImageSliderSection } from './components/ImageSliderSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { HowItWorks } from './components/HowItWorks';
import { SocialSection } from './components/SocialSection';
import { ContactSection } from './components/ContactSection';
import { FloatingActions } from './components/FloatingActions';
import { Footer } from './components/Footer';
import { InquiryModal } from './components/InquiryModal';

export default function App() {
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const [inquiryModalOpen, setInquiryModalOpen] = useState<boolean>(false);
  const [inquiryTopic, setInquiryTopic] = useState<string>('');

  const handleOpenInquiry = (topic?: string) => {
    setInquiryTopic(topic || 'Available Smartphone Deals');
    setInquiryModalOpen(true);
  };

  const handleSelectCategory = (categoryName: string) => {
    // Scroll to mobiles section
    const elem = document.getElementById('mobiles');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#05070c] text-neutral-100 flex flex-col selection:bg-amber-500 selection:text-black">
      {/* 3D Smartphone Advertisement Loading / First Visit Experience */}
      <IntroExperience
        isOpen={showIntro}
        onComplete={() => setShowIntro(false)}
      />

      {/* Modern Sticky Navigation Bar */}
      <Navbar
        onOpenIntro={() => setShowIntro(true)}
        onOpenInquiry={handleOpenInquiry}
      />

      {/* Main Website Sections */}
      <main className="flex-1">
        {/* Hero Section with Auto Slider, Zoom, and Call/WhatsApp Actions */}
        <HeroSection onOpenInquiry={handleOpenInquiry} />

        {/* About Anjani Mobile Store with Upward Animated Counters */}
        <AboutSection />

        {/* 8 Premium Category Cards with 3D Tilt & Glow Effects */}
        <CategorySection
          onSelectCategory={handleSelectCategory}
          onOpenInquiry={handleOpenInquiry}
        />

        {/* Featured Mobile Product Showcase with Testing Info & Badges */}
        <FeaturedShowcase
          onOpenInquiry={handleOpenInquiry}
        />

        {/* Interactive Sell & Exchange Phone Valuation Tool */}
        <PhoneValuationCalculator />

        {/* Premium 3-Second Auto-Changing Framed Gallery */}
        <AutoGallery />

        {/* Wide Store Atmosphere & Device Showcase Slider */}
        <ImageSliderSection />

        {/* Why Choose Us: 8 Verified Points with Animated Cards */}
        <WhyChooseUs />

        {/* How It Works: 3-Step Animated Process */}
        <HowItWorks />

        {/* Social Media Section: YouTube & Instagram */}
        <SocialSection />

        {/* Contact Section: Phone, WhatsApp, Emergency 24/7, Address, Directions */}
        <ContactSection />
      </main>

      {/* Floating Action Buttons: WhatsApp, Call Now, Emergency Contact */}
      <FloatingActions />

      {/* Luxury Footer */}
      <Footer />

      {/* Interactive WhatsApp Inquiry Modal */}
      <InquiryModal
        isOpen={inquiryModalOpen}
        onClose={() => setInquiryModalOpen(false)}
        phoneTopic={inquiryTopic}
      />
    </div>
  );
}
