import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';
import { Logo } from './Logo';

interface IntroExperienceProps {
  onComplete: () => void;
  isOpen: boolean;
}

export const IntroExperience: React.FC<IntroExperienceProps> = ({ onComplete, isOpen }) => {
  const [rotation, setRotation] = useState({ x: 10, y: -12 });

  useEffect(() => {
    if (!isOpen) return;
    // Auto transition smoothly after 12s if user just observes
    const timer = setTimeout(() => {
      // Optional timeout
    }, 12000);
    return () => clearTimeout(timer);
  }, [isOpen]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    setRotation({
      x: -(y / rect.height) * 25,
      y: (x / rect.width) * 30,
    });
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches[0]) {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.touches[0].clientX - rect.left - rect.width / 2;
      const y = e.touches[0].clientY - rect.top - rect.height / 2;
      setRotation({
        x: -(y / rect.height) * 20,
        y: (x / rect.width) * 22,
      });
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        id="intro-experience-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.7, ease: 'easeInOut' } }}
        className="fixed inset-0 z-50 flex flex-col justify-between bg-[#04060a] text-white overflow-y-auto overflow-x-hidden select-none py-4 sm:py-6 px-4"
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
      >
        {/* Dynamic Background Mesh & Animated Particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {/* Central Radial Aura */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] sm:w-[850px] sm:h-[850px] bg-gradient-to-tr from-amber-500/15 via-blue-600/10 to-purple-600/15 rounded-full blur-[120px] animate-pulse" />
          
          {/* Tech Grid Lines */}
          <div className="absolute inset-0 opacity-15 bg-[linear-gradient(to_right,#1f293d_1px,transparent_1px),linear-gradient(to_bottom,#1f293d_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

          {/* Floating light particles */}
          {[...Array(14)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-amber-400 rounded-full"
              initial={{
                x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 800),
                y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800),
                opacity: 0.2,
                scale: 0.5,
              }}
              animate={{
                y: ['-15px', '15px', '-15px'],
                opacity: [0.2, 0.7, 0.2],
                scale: [0.5, 1.2, 0.5],
              }}
              transition={{
                duration: 4 + (i % 4),
                repeat: Infinity,
                ease: 'easeInOut',
                delay: i * 0.25,
              }}
            />
          ))}
        </div>

        {/* Top Header: Premium Brand Identity */}
        <div className="relative z-10 w-full max-w-5xl mx-auto flex items-center justify-center">
          <div className="py-1 px-4 rounded-full bg-white/[0.03] border border-white/10 backdrop-blur-md shadow-lg">
            <Logo size="sm" showTagline={true} />
          </div>
        </div>

        {/* Center 3D Smartphone Advertisement Rig */}
        <div className="relative z-10 flex flex-col items-center justify-center w-full max-w-4xl mx-auto my-auto py-2">
          {/* Header Typography */}
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-3 sm:mb-5"
          >
            <span className="inline-block text-[10px] sm:text-xs font-bold uppercase tracking-[0.25em] text-amber-400 mb-1.5 px-3 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
              WELCOME TO
            </span>
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight text-white font-['Outfit',sans-serif]">
              ANJANI MOBILE <span className="gold-text-gradient">STORE</span>
            </h1>
            <p className="mt-1 text-[11px] sm:text-xs tracking-widest text-neutral-400 font-semibold uppercase">
              PRE-OWNED MOBILES • BEST DEALS • TRUSTED STORE
            </p>
          </motion.div>

          {/* 3D Phone Container (Responsive height for mobile) */}
          <div
            onClick={onComplete}
            title="Click or Tap to Enter Showroom"
            className="relative w-64 h-[370px] sm:w-72 sm:h-[440px] perspective-1000 flex items-center justify-center cursor-pointer group"
          >
            {/* Ambient Back Glow */}
            <div className="absolute inset-0 bg-gradient-to-t from-amber-500/25 via-cyan-500/20 to-transparent blur-3xl -z-10 rounded-full" />

            {/* The 3D Floating Smartphone */}
            <motion.div
              style={{
                transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
                transition: 'transform 0.15s ease-out',
              }}
              animate={{
                y: [-6, 6, -6],
                scale: [0.98, 1.01, 0.98],
              }}
              transition={{
                duration: 5.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="relative w-60 h-[360px] sm:w-68 sm:h-[430px] rounded-[38px] sm:rounded-[42px] p-[2.5px] bg-gradient-to-b from-amber-200/80 via-neutral-600 to-neutral-800 shadow-[0_25px_50px_-15px_rgba(0,0,0,0.95),0_0_35px_rgba(245,158,11,0.3)] preserve-3d"
            >
              {/* Outer Metallic Edge Bezel */}
              <div className="relative w-full h-full rounded-[35px] sm:rounded-[39px] bg-[#0c1017] p-2 overflow-hidden flex flex-col justify-between border border-neutral-700/60 shadow-inner">
                {/* Dynamic Reflection Glare across Screen */}
                <div className="absolute -inset-full bg-gradient-to-tr from-transparent via-white/12 to-transparent rotate-45 pointer-events-none animate-shimmer" />

                {/* Top Notch / Dynamic Island */}
                <div className="relative z-20 flex items-center justify-between px-3 pt-1">
                  <span className="text-[10px] font-semibold text-neutral-300">9:41</span>
                  {/* Dynamic Island */}
                  <div className="w-16 h-3.5 rounded-full bg-black border border-neutral-800 flex items-center justify-end px-2 gap-1 shadow-md">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500/80" />
                    <div className="w-1.5 h-1.5 rounded-full bg-neutral-900 border border-neutral-700" />
                  </div>
                  <div className="flex items-center gap-1 text-neutral-300 text-[9px]">
                    <span>5G</span>
                    <div className="w-3 h-1.5 border border-neutral-300 rounded-[2px] p-[0.5px]">
                      <div className="w-full h-full bg-emerald-400 rounded-[1px]" />
                    </div>
                  </div>
                </div>

                {/* Screen Wallpaper Content */}
                <div className="relative z-10 flex-1 my-1.5 rounded-[24px] sm:rounded-[28px] overflow-hidden bg-gradient-to-b from-[#111827] via-[#090e18] to-[#03060d] border border-white/5 flex flex-col items-center justify-center p-3 text-center">
                  
                  {/* Premium Crest Inside Phone */}
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl p-[1.5px] bg-gradient-to-b from-amber-200 via-amber-500 to-amber-700 shadow-lg shadow-amber-500/40 mb-2">
                    <div className="w-full h-full rounded-[14px] bg-[#080c14] flex items-center justify-center p-2">
                      <Logo size="sm" showText={false} />
                    </div>
                  </div>

                  <span className="text-[9px] font-bold tracking-widest text-amber-400 uppercase bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    100% Genuine
                  </span>

                  <h3 className="text-base sm:text-lg font-black text-white mt-1 font-['Outfit',sans-serif]">
                    ANJANI STORE
                  </h3>
                  <p className="text-[10px] text-neutral-300 mt-0.5 max-w-[170px] leading-tight">
                    Guwahati's Verified Flagship Second-Hand Showroom
                  </p>

                  <div className="mt-3 grid grid-cols-2 gap-1.5 w-full text-[9px]">
                    <div className="p-1 rounded-lg bg-white/5 border border-white/10 text-neutral-200 flex items-center justify-center gap-1 font-semibold">
                      <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
                      40-Pt Tested
                    </div>
                    <div className="p-1 rounded-lg bg-white/5 border border-white/10 text-neutral-200 flex items-center justify-center gap-1 font-semibold">
                      <Zap className="w-2.5 h-2.5 text-amber-400" />
                      Best Deals
                    </div>
                  </div>

                  <div className="mt-3 w-full py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold text-[11px] shadow-md shadow-amber-500/30 group-hover:scale-105 transition-transform">
                    Tap to Enter Store
                  </div>
                </div>

                {/* Bottom Home Bar */}
                <div className="relative z-20 flex justify-center pb-0.5">
                  <div className="w-24 h-1 rounded-full bg-white/40" />
                </div>
              </div>

              {/* Edge Buttons Simulation */}
              <div className="absolute -left-[4px] top-20 w-[3px] h-7 bg-neutral-600 rounded-l-sm" />
              <div className="absolute -left-[4px] top-30 w-[3px] h-7 bg-neutral-600 rounded-l-sm" />
              <div className="absolute -right-[4px] top-24 w-[3px] h-10 bg-neutral-600 rounded-r-sm" />
            </motion.div>
          </div>

          <p className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            Move or tilt to inspect • Tap phone to enter
          </p>
        </div>

        {/* Bottom Call to Action */}
        <div className="relative z-10 w-full max-w-md mx-auto pt-1 pb-2 text-center">
          <motion.button
            id="intro-enter-showroom-button"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            onClick={onComplete}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-black font-extrabold text-sm sm:text-base tracking-wide shadow-[0_0_30px_rgba(245,158,11,0.45)] flex items-center justify-center gap-2.5 mx-auto transition-all"
          >
            <span>ENTER SHOWROOM</span>
            <ArrowRight className="w-4 h-4 text-black" />
          </motion.button>

          <div className="mt-2.5 flex items-center justify-center gap-3 text-[10px] text-neutral-400">
            <span>Beltala, Guwahati</span>
            <span>•</span>
            <span>WhatsApp: {STORE_INFO.contacts.whatsapp}</span>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

