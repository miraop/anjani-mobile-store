import React from 'react';
import { motion } from 'motion/react';
import { Smartphone, MessageSquareText, Sparkles, ArrowRight, CheckCircle, ShieldCheck } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Choose Your Mobile',
      tag: 'Step 1',
      desc: 'Browse our tested stock of Apple iPhones, Samsung flagships, and Android phones online or in our Beltala showroom.',
      icon: <Smartphone className="w-6 h-6 text-amber-400" />,
      badge: 'Certified Inventory',
    },
    {
      num: '02',
      title: 'Contact Us on WhatsApp or Call',
      tag: 'Step 2',
      desc: 'Send a quick WhatsApp text or call us directly. We provide real photos, battery diagnostic reports, and lock in your price.',
      icon: <MessageSquareText className="w-6 h-6 text-emerald-400" />,
      badge: 'Fast Response',
    },
    {
      num: '03',
      title: 'Get the Best Deal',
      tag: 'Step 3',
      desc: 'Walk into Anjani Mobile Store at Ezzey Bazzar, test the device yourself, or arrange express delivery in Guwahati with warranty.',
      icon: <Sparkles className="w-6 h-6 text-amber-300" />,
      badge: 'Testing Warranty',
    },
  ];

  return (
    <section id="how-it-works" className="py-20 bg-[#070a13] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-widest mb-3">
            <CheckCircle className="w-3.5 h-3.5" />
            Simple 3-Step Process
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            HOW IT <span className="gold-text-gradient">WORKS</span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            Buying or exchanging your smartphone at Anjani Mobile Store is transparent, fast, and stress-free.
          </p>
        </div>

        {/* 3 Step Process with Connecting Line */}
        <div className="relative">
          {/* Desktop connecting glowing line */}
          <div className="hidden lg:block absolute top-1/2 left-[15%] right-[15%] h-[2px] bg-gradient-to-r from-amber-500/20 via-emerald-500/30 to-amber-500/20 -translate-y-6 z-0" />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative z-10">
            {steps.map((step, idx) => (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                className="relative rounded-3xl p-8 bg-gradient-to-b from-[#131b2c] to-[#0a0f19] border border-white/10 hover:border-amber-500/40 transition-all duration-300 shadow-xl flex flex-col justify-between group"
              >
                {/* Step Number Top Badge */}
                <div className="flex items-center justify-between mb-6">
                  <span className="text-3xl font-black text-amber-500/40 group-hover:text-amber-400 transition-colors">
                    {step.num}
                  </span>
                  <span className="text-xs font-bold text-neutral-300 bg-white/5 px-3 py-1 rounded-full border border-white/10">
                    {step.badge}
                  </span>
                </div>

                {/* Icon in Center */}
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform group-hover:bg-amber-500/10 group-hover:border-amber-500/30">
                  {step.icon}
                </div>

                {/* Step Title & Description */}
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
                    {step.desc}
                  </p>
                </div>

                {/* Bottom Step Indicator */}
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-neutral-400">
                  <span className="font-semibold text-amber-400">{step.tag}</span>
                  <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA banner under steps */}
        <div className="mt-14 text-center">
          <a
            id="how-it-works-start-btn"
            href={createWhatsAppLink("Hi Anjani Mobile Store! I saw your 3-step buying process on the website. I want to buy/exchange a phone.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-emerald-500/25 hover:scale-105 transition-all"
          >
            <span>Start Step 1: Browse Available Stock on WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};
