import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Phone, AlertCircle, ChevronUp, ChevronDown, MapPin, X } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';

export const FloatingActions: React.FC = () => {
  const [minimized, setMinimized] = useState(false);

  return (
    <div
      id="floating-action-buttons"
      className="fixed bottom-5 right-4 sm:right-6 z-40 flex flex-col items-end gap-2.5 select-none"
    >
      <AnimatePresence>
        {!minimized && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="flex flex-col items-end gap-2.5"
          >
            {/* 1. Emergency Contact Button (Red Pulse) */}
            <a
              id="floating-emergency-btn"
              href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
              className="group flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#1e0a0e]/90 hover:bg-rose-900/90 border border-rose-500/60 text-rose-200 text-xs font-bold shadow-xl backdrop-blur-md transition-all animate-emergency-pulse hover:scale-105"
              title="24/7 Emergency Call & WhatsApp: +91 7099009971"
            >
              <div className="w-5 h-5 rounded-full bg-rose-600 flex items-center justify-center text-white shrink-0">
                <AlertCircle className="w-3.5 h-3.5" />
              </div>
              <span className="hidden sm:inline">Emergency Line</span>
              <span className="text-[11px] font-mono text-rose-300">7099009971</span>
            </a>

            {/* 2. Direct Call Now Button (Blue) */}
            <a
              id="floating-call-btn"
              href={`tel:${STORE_INFO.contacts.callClean}`}
              className="group flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#0a1526]/90 hover:bg-blue-900/90 border border-blue-500/50 text-blue-200 text-xs font-bold shadow-xl backdrop-blur-md transition-all hover:scale-105"
              title="Call Store Manager: +91 6900524178"
            >
              <div className="w-5 h-5 rounded-full bg-blue-600 flex items-center justify-center text-white shrink-0">
                <Phone className="w-3.5 h-3.5" />
              </div>
              <span className="hidden sm:inline">Call Now</span>
              <span className="text-[11px] font-mono text-blue-300">6900524178</span>
            </a>

            {/* 3. Official WhatsApp Button (Green Pulse - Primary Action) */}
            <a
              id="floating-whatsapp-btn"
              href={createWhatsAppLink("Hi Anjani Mobile Store! I'm on your website and would like to ask about mobile deals in Beltala.")}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 px-5 py-3.5 rounded-full bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-extrabold text-sm shadow-[0_10px_25px_-5px_rgba(16,185,129,0.6)] backdrop-blur-md transition-all animate-pulse-glow hover:scale-105"
              title="WhatsApp: +91 7002312833"
            >
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                <MessageCircle className="w-4 h-4 fill-white" />
              </div>
              <span>WhatsApp Us</span>
              <span className="hidden sm:inline text-xs font-mono font-medium opacity-90">7002312833</span>
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Minimize / Expand Toggle Pill */}
      <button
        id="toggle-floating-menu-btn"
        onClick={() => setMinimized(!minimized)}
        className="px-2.5 py-1 rounded-full bg-black/60 hover:bg-black/90 text-[10px] text-neutral-400 hover:text-white border border-white/10 backdrop-blur-md transition-all flex items-center gap-1"
        aria-label="Toggle Quick Contact Buttons"
      >
        {minimized ? (
          <>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Contact Store</span>
            <ChevronUp className="w-3 h-3" />
          </>
        ) : (
          <>
            <span>Hide</span>
            <ChevronDown className="w-3 h-3" />
          </>
        )}
      </button>
    </div>
  );
};
