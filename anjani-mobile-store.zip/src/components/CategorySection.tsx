import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowUpRight, ShieldCheck, Repeat, Smartphone, Cpu, Wallet, Banknote, CheckCircle2 } from 'lucide-react';
import { CATEGORIES, SAFE_IMAGE_FALLBACK, createWhatsAppLink } from '../data/storeData';

interface CategorySectionProps {
  onSelectCategory: (categoryName: string) => void;
  onOpenInquiry: (topic: string) => void;
}

export const CategorySection: React.FC<CategorySectionProps> = ({ onSelectCategory, onOpenInquiry }) => {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-amber-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'Wallet':
        return <Wallet className="w-5 h-5 text-amber-400" />;
      case 'Smartphone':
        return <Smartphone className="w-5 h-5 text-amber-400" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-amber-400" />;
      case 'Repeat':
        return <Repeat className="w-5 h-5 text-amber-400" />;
      case 'CheckCircle2':
        return <CheckCircle2 className="w-5 h-5 text-amber-400" />;
      case 'Banknote':
        return <Banknote className="w-5 h-5 text-amber-400" />;
      default:
        return <Smartphone className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <section id="categories" className="py-20 bg-[#05070c] relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Explore Our Specialized Services
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            MOBILE <span className="gold-text-gradient">CATEGORIES</span> & SERVICES
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            From flagship iPhones to budget daily phones, exchange options, and instant selling — find the exact category suited for your needs.
          </p>
        </div>

        {/* 8 Category Cards with 3D Tilt & Glow Effects */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {CATEGORIES.map((cat, idx) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              onMouseEnter={() => setHoveredCard(cat.id)}
              onMouseLeave={() => setHoveredCard(null)}
              className="group relative rounded-3xl p-4 bg-gradient-to-b from-[#121826] to-[#0a0e17] border border-white/10 hover:border-amber-500/50 transition-all duration-500 hover:shadow-[0_15px_35px_-5px_rgba(245,158,11,0.2)] flex flex-col justify-between overflow-hidden"
              style={{
                transform: hoveredCard === cat.id ? 'translateY(-6px) perspective(1000px) rotateX(2deg)' : 'none',
              }}
            >
              {/* Image Container with Zoom Animation */}
              <div className="relative h-44 rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a2333] to-[#080d16] mb-4">
                <img
                  src={cat.image}
                  alt={cat.title}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    if (target.src !== SAFE_IMAGE_FALLBACK) {
                      target.src = SAFE_IMAGE_FALLBACK;
                    }
                  }}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e17] via-transparent to-transparent opacity-80" />

                {/* Top Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-black/75 backdrop-blur-md text-amber-300 px-2.5 py-1 rounded-full border border-white/15">
                    {cat.badge}
                  </span>
                </div>

                <div className="absolute top-3 right-3">
                  <span className="text-[10px] font-semibold bg-white/10 backdrop-blur-md text-neutral-200 px-2 py-0.5 rounded-md border border-white/10">
                    {cat.count}
                  </span>
                </div>

                {/* Corner floating icon */}
                <div className="absolute bottom-3 left-3 w-9 h-9 rounded-xl bg-black/70 backdrop-blur-md border border-white/15 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-black transition-all">
                  {getIcon(cat.icon)}
                </div>
              </div>

              {/* Text Info */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors flex items-center justify-between">
                    <span>{cat.title}</span>
                    <ArrowUpRight className="w-4 h-4 text-neutral-400 group-hover:text-amber-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                  </h3>
                  <p className="mt-1.5 text-xs text-neutral-400 leading-relaxed">
                    {cat.desc}
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                  <button
                    id={`cat-explore-${cat.id}`}
                    onClick={() => {
                      if (cat.id === 'cat-sellmobile' || cat.id === 'cat-exchange') {
                        onOpenInquiry(`${cat.title} inquiry for Guwahati customer`);
                      } else {
                        onSelectCategory(cat.title);
                      }
                    }}
                    className="w-full py-2 rounded-xl bg-white/5 hover:bg-amber-500 hover:text-black text-neutral-300 font-bold text-xs transition-all text-center"
                  >
                    {cat.id === 'cat-sellmobile' ? 'Sell Now / Get Quote' : cat.id === 'cat-exchange' ? 'Exchange Value' : 'View Models'}
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
