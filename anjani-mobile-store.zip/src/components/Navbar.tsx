import React, { useState, useEffect } from 'react';
import { Phone, MessageCircle, Menu, X, Sparkles, MapPin, AlertCircle } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';
import { Logo } from './Logo';

interface NavbarProps {
  onOpenIntro: () => void;
  onOpenInquiry: (initialTopic?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenIntro, onOpenInquiry }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#hero' },
    { label: 'About Us', href: '#about' },
    { label: 'Mobiles', href: '#mobiles' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Why Choose Us', href: '#why-choose-us' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'bg-[#060912]/95 backdrop-blur-xl border-b border-white/10 shadow-[0_10px_30px_rgba(0,0,0,0.8)] py-2.5'
          : 'bg-gradient-to-b from-[#060912]/95 via-[#060912]/70 to-transparent py-3.5 sm:py-4'
      }`}
    >
      {/* Top Banner Notice for Beltala Store */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <a
            id="nav-logo-link"
            href="#hero"
            className="flex items-center"
          >
            <Logo size="md" showTagline={true} />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs xl:text-sm font-medium text-neutral-300 hover:text-amber-400 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-amber-400 hover:after:w-full after:transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action Buttons: WhatsApp & Call & 3D Intro */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* 3D View Button */}
            <button
              id="navbar-3d-intro-btn"
              onClick={onOpenIntro}
              title="View 3D Smartphone Advertisement"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-neutral-300 hover:text-white transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
              <span className="hidden md:inline">3D View</span>
            </button>

            {/* Direct Call Button */}
            <a
              id="navbar-call-btn"
              href={`tel:${STORE_INFO.contacts.callClean}`}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-300 hover:text-blue-100 text-xs font-semibold transition-all shadow-sm"
            >
              <Phone className="w-3.5 h-3.5 text-blue-400" />
              <span>Call</span>
            </a>

            {/* WhatsApp Us Button */}
            <a
              id="navbar-whatsapp-btn"
              href={createWhatsAppLink("Hi Anjani Mobile Store, I am visiting your website and would like to check your available phone stock.")}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/30"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white" />
              <span>WhatsApp</span>
            </a>

            {/* Emergency Contact Button */}
            <a
              id="navbar-emergency-btn"
              href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
              title="Emergency Call & WhatsApp: +91 7099009971"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 text-xs font-semibold transition-all animate-pulse"
            >
              <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden xl:inline">Emergency</span>
            </a>
          </div>

          {/* Mobile Hamburger Button */}
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-neutral-200 lg:hidden"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="lg:hidden fixed inset-x-0 top-full bg-[#060912]/98 backdrop-blur-2xl border-b border-white/10 px-6 py-6 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-top-2 duration-200"
        >
          <div className="grid grid-cols-2 gap-2 pb-2">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-sm font-medium text-neutral-200 hover:text-amber-400 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Quick Actions in Mobile Drawer */}
          <div className="pt-2 border-t border-white/10 flex flex-col gap-2.5">
            <div className="grid grid-cols-2 gap-2">
              <a
                id="mobile-drawer-call-btn"
                href={`tel:${STORE_INFO.contacts.callClean}`}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-300 font-semibold text-xs"
              >
                <Phone className="w-4 h-4 text-blue-400" />
                Call Us
              </a>
              <a
                id="mobile-drawer-whatsapp-btn"
                href={createWhatsAppLink("Hi Anjani Mobile Store, I would like to inquire about available phones.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                WhatsApp
              </a>
            </div>

            <a
              id="mobile-drawer-emergency-btn"
              href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-rose-600/20 border border-rose-500/40 text-rose-300 font-bold text-xs animate-emergency-pulse"
            >
              <AlertCircle className="w-4 h-4 text-rose-400" />
              Emergency Line: +91 7099009971
            </a>

            <button
              id="mobile-drawer-3d-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenIntro();
              }}
              className="flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/10 text-white font-medium text-xs border border-white/10"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              Replay 3D Phone Intro
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
