import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Phone, Search, Sparkles, Battery, Box, ShieldCheck, Check } from 'lucide-react';
import { FEATURED_PRODUCTS, Product, STORE_INFO, createWhatsAppLink, SAFE_IMAGE_FALLBACK } from '../data/storeData';

interface FeaturedShowcaseProps {
  onOpenInquiry: (phoneName: string) => void;
  selectedCategoryFilter?: string | null;
}

export const FeaturedShowcase: React.FC<FeaturedShowcaseProps> = ({ onOpenInquiry, selectedCategoryFilter }) => {
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const brands = ['All', 'Apple', 'Samsung', 'OnePlus', 'Google'];

  const filteredProducts = FEATURED_PRODUCTS.filter((prod) => {
    const matchesBrand = selectedBrand === 'All' || prod.brand === selectedBrand;
    const matchesSearch = prod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          prod.storage.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          prod.color.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesBrand && matchesSearch;
  });

  return (
    <section id="mobiles" className="py-20 bg-[#070b14] relative overflow-hidden">
      {/* Glow decorations */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Verified Pre-Owned Inventory
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            FEATURED <span className="gold-text-gradient">MOBILE SHOWCASE</span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            Hand-picked, 40-point tested smartphones currently available at our Beltala showroom. 
            Real condition grading, clean IMEI, and testing warranty included with every purchase.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10 pb-6 border-b border-white/10">
          {/* Brand Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
            {brands.map((brand) => (
              <button
                key={brand}
                onClick={() => setSelectedBrand(brand)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                  selectedBrand === brand
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/25 font-bold'
                    : 'bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10'
                }`}
              >
                {brand === 'All' ? 'All Mobiles' : brand}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search model or storage..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-500 text-xs sm:text-sm focus:outline-none focus:border-amber-500/50 transition-colors"
            />
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredProducts.map((product, idx) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              whileHover={{ y: -6 }}
              className="rounded-3xl p-5 bg-gradient-to-b from-[#131a29] to-[#0b101b] border border-white/10 hover:border-amber-500/40 shadow-xl hover:shadow-[0_20px_40px_rgba(0,0,0,0.8)] transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    {product.condition}
                  </span>

                  {product.highlightTag && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wide">
                      {product.highlightTag}
                    </span>
                  )}
                </div>

                {/* Smartphone Visual Container */}
                <div className="relative h-56 rounded-2xl overflow-hidden bg-gradient-to-br from-[#121927] to-[#080d16] mb-4 border border-white/5 flex items-center justify-center p-3">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.currentTarget as HTMLImageElement;
                      if (target.src !== SAFE_IMAGE_FALLBACK) {
                        target.src = SAFE_IMAGE_FALLBACK;
                      }
                    }}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b101b] via-transparent to-transparent opacity-60" />

                  {/* Storage Floating Badge */}
                  <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/15 text-[11px] font-bold text-white">
                    {product.storage}
                  </div>
                </div>

                {/* Product Titles & Specifications */}
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-neutral-400">
                      {product.brand}
                    </span>
                    <span className="text-xs text-neutral-400 font-medium">
                      Color: {product.color}
                    </span>
                  </div>

                  <h3 className="text-lg font-extrabold text-white mt-0.5 group-hover:text-amber-400 transition-colors">
                    {product.name}
                  </h3>

                  {/* Battery & Hardware Status */}
                  {product.batteryHealth && (
                    <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-500/20 w-fit">
                      <Battery className="w-3.5 h-3.5" />
                      <span>{product.batteryHealth}</span>
                    </div>
                  )}

                  {/* Includes List */}
                  <div className="mt-3 pt-3 border-t border-white/5 space-y-1">
                    <p className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">
                      Package Includes:
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {product.includes.map((item, i) => (
                        <span
                          key={i}
                          className="text-[10px] text-neutral-300 bg-white/5 px-2 py-0.5 rounded border border-white/5 flex items-center gap-1"
                        >
                          <Check className="w-2.5 h-2.5 text-amber-400" />
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons: Instant WhatsApp Inquiry & Call */}
              <div className="mt-5 pt-4 border-t border-white/10 flex items-center gap-2">
                <a
                  id={`product-inquire-${product.id}`}
                  href={createWhatsAppLink(`Hi Anjani Mobile Store! I am interested in purchasing ${product.name} (${product.storage}, ${product.color}, Condition: ${product.condition}). Is it available at Beltala store?`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 text-center"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>Inquire on WhatsApp</span>
                </a>

                <button
                  id={`product-call-quick-${product.id}`}
                  onClick={() => onOpenInquiry(product.name)}
                  className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/10 transition-all"
                  title="Quick Details"
                >
                  Details
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Note for Store Owner / Customers */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-amber-500/10 via-white/5 to-transparent border border-amber-500/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Looking for a specific model not listed here?
            </h4>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1">
              Our inventory changes daily at Ezzey Bazzar, Beltala! WhatsApp us your desired model and budget — we will source it with full warranty.
            </p>
          </div>

          <a
            id="custom-model-request-btn"
            href={createWhatsAppLink("Hi Anjani Mobile Store! I am looking for a specific mobile phone model that I didn't see on the website.")}
            target="_blank"
            rel="noopener noreferrer"
            className="whitespace-nowrap px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs tracking-wide shadow-md transition-all"
          >
            Request Any Model
          </a>
        </div>
      </div>
    </section>
  );
};
