import React, { useState } from 'react';
import { motion } from 'motion/react';
import { RefreshCw, ArrowRight, ShieldCheck, Check, Sparkles, MessageCircle } from 'lucide-react';
import { createWhatsAppLink } from '../data/storeData';

export const PhoneValuationCalculator: React.FC = () => {
  const [phoneBrand, setPhoneBrand] = useState('Apple');
  const [modelName, setModelName] = useState('');
  const [storage, setStorage] = useState('128GB');
  const [condition, setCondition] = useState('Flawless (Like New)');
  const [hasBoxBill, setHasBoxBill] = useState(true);
  const [mode, setMode] = useState<'sell' | 'exchange'>('sell');

  const handleInquire = () => {
    const text = `Hello Anjani Mobile Store! I want to ${mode.toUpperCase()} my phone.
- Brand: ${phoneBrand}
- Model: ${modelName || 'Not specified'}
- Storage: ${storage}
- Condition: ${condition}
- Original Box & Bill: ${hasBoxBill ? 'Yes available' : 'No'}
Please give me your best ${mode === 'sell' ? 'cash buyout' : 'exchange'} value for Guwahati!`;

    window.open(createWhatsAppLink(text), '_blank');
  };

  return (
    <section id="sell-exchange" className="py-20 bg-[#05070c] relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-r from-amber-500/10 via-purple-500/5 to-blue-500/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <RefreshCw className="w-3.5 h-3.5" />
            Instant Valuation & Trade-In
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            SELL OR EXCHANGE <span className="gold-text-gradient">YOUR PHONE</span>
          </h2>
          <p className="mt-2 text-sm sm:text-base text-neutral-300">
            Get instant spot cash or trade up to your dream smartphone at our Beltala showroom with Guwahati's highest exchange value.
          </p>
        </div>

        {/* Valuation Box */}
        <div className="rounded-3xl p-6 sm:p-10 bg-gradient-to-b from-[#131a29] to-[#0a0f19] border border-white/15 shadow-2xl">
          {/* Mode Switcher: Sell vs Exchange */}
          <div className="flex items-center justify-center mb-8">
            <div className="p-1 rounded-2xl bg-black/50 border border-white/10 flex items-center gap-2">
              <button
                onClick={() => setMode('sell')}
                className={`px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                  mode === 'sell'
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                💵 Sell for Instant Cash
              </button>
              <button
                onClick={() => setMode('exchange')}
                className={`px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                  mode === 'exchange'
                    ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                🔄 Exchange & Upgrade
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Brand Selection */}
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-300 tracking-wider mb-2">
                1. Select Brand
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['Apple', 'Samsung', 'OnePlus', 'Vivo', 'Realme', 'Other'].map((b) => (
                  <button
                    key={b}
                    onClick={() => setPhoneBrand(b)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      phoneBrand === b
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                        : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            {/* Model Name Input */}
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-300 tracking-wider mb-2">
                2. Enter Model Name
              </label>
              <input
                type="text"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                placeholder="e.g. iPhone 13, Galaxy S22, OnePlus 9..."
                className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-amber-500/50"
              />
            </div>

            {/* Storage Selection */}
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-300 tracking-wider mb-2">
                3. Storage Capacity
              </label>
              <div className="grid grid-cols-4 gap-2">
                {['64GB', '128GB', '256GB', '512GB+'].map((s) => (
                  <button
                    key={s}
                    onClick={() => setStorage(s)}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                      storage === s
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                        : 'bg-white/5 border-white/10 text-neutral-300 hover:bg-white/10'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Device Condition */}
            <div>
              <label className="block text-xs font-bold uppercase text-neutral-300 tracking-wider mb-2">
                4. Physical Condition
              </label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0e1422] border border-white/10 text-white text-sm focus:outline-none focus:border-amber-500/50"
              >
                <option value="Flawless (Like New, Zero Scratches)">Flawless (Like New, Zero Scratches)</option>
                <option value="Good (Minor Normal Wear)">Good (Minor Normal Wear)</option>
                <option value="Fair (Visible Scratches / Dents)">Fair (Visible Scratches / Dents)</option>
                <option value="Screen or Back Damaged">Screen or Back Damaged</option>
              </select>
            </div>
          </div>

          {/* Box & Bill Toggle */}
          <div className="mt-6 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={hasBoxBill}
                onChange={(e) => setHasBoxBill(e.target.checked)}
                className="w-5 h-5 rounded border-white/20 bg-white/5 text-amber-500 focus:ring-amber-500"
              />
              <span className="text-xs sm:text-sm text-neutral-200">
                I have original box / charger / bill (Boosts valuation)
              </span>
            </label>

            <button
              id="get-instant-quote-btn"
              onClick={handleInquire}
              className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all hover:scale-105"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Get Instant Quote on WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
