import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Phone, MessageCircle, AlertCircle, MapPin, Navigation, Clock, Send, CheckCircle } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    interest: 'Buying a Phone',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = `New Website Inquiry:
Name: ${formData.name || 'Not provided'}
Phone: ${formData.phone || 'Not provided'}
Interest: ${formData.interest}
Message: ${formData.message || 'Looking for available deals'}`;

    window.open(createWhatsAppLink(text), '_blank');
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-[#04060c] relative overflow-hidden">
      {/* Background radial aura */}
      <div className="absolute top-1/3 right-1/4 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <MapPin className="w-3.5 h-3.5" />
            Visit or Get in Touch
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            CONTACT <span className="gold-text-gradient">ANJANI MOBILE STORE</span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            We are here to help you get the best deal on your next smartphone. Reach out via call, WhatsApp, or drop by our showroom at Beltala Jayanagar Charali.
          </p>
        </div>

        {/* 4 Contact Cards: Call, WhatsApp, Emergency, Address */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          
          {/* Card 1: CALL US */}
          <motion.div
            whileHover={{ y: -5 }}
            className="p-6 rounded-3xl bg-gradient-to-b from-[#131b2c] to-[#0a0f19] border border-blue-500/20 hover:border-blue-500/50 transition-all shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 mb-4">
                <Phone className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400">
                Direct Phone Line
              </span>
              <h3 className="text-xl font-bold text-white mt-1">CALL US</h3>
              <p className="text-sm font-semibold text-neutral-300 mt-2">
                {STORE_INFO.contacts.call}
              </p>
              <p className="text-xs text-neutral-400 mt-1">
                Mon - Sun: 10:00 AM - 9:30 PM
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
              <a
                id="contact-call-btn"
                href={`tel:${STORE_INFO.contacts.callClean}`}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-blue-600/20"
              >
                <Phone className="w-4 h-4" />
                <span>Call Now</span>
              </a>
            </div>
          </motion.div>

          {/* Card 2: WHATSAPP */}
          <motion.div
            whileHover={{ y: -5 }}
            className="p-6 rounded-3xl bg-gradient-to-b from-[#0f1d1a] to-[#071310] border border-emerald-500/20 hover:border-emerald-500/50 transition-all shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-4">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                Instant Chat & Photos
              </span>
              <h3 className="text-xl font-bold text-white mt-1">WHATSAPP</h3>
              <p className="text-sm font-semibold text-neutral-300 mt-2">
                {STORE_INFO.contacts.whatsapp}
              </p>
              <p className="text-xs text-neutral-400 mt-1">
                Get real live device photos & battery stats
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
              <a
                id="contact-whatsapp-btn"
                href={createWhatsAppLink("Hi Anjani Mobile Store! I am contacting you through your website.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/20"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Card 3: EMERGENCY CALL & WHATSAPP */}
          <motion.div
            whileHover={{ y: -5 }}
            className="p-6 rounded-3xl bg-gradient-to-b from-[#241318] to-[#12080c] border border-rose-500/30 hover:border-rose-500/60 transition-all shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-4 animate-pulse">
                <AlertCircle className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                24/7 Priority Support
              </span>
              <h3 className="text-xl font-bold text-white mt-1 leading-snug">
                EMERGENCY CALL & WHATSAPP
              </h3>
              <p className="text-sm font-semibold text-rose-300 mt-2">
                {STORE_INFO.contacts.emergency}
              </p>
              <p className="text-xs text-neutral-400 mt-1">
                Urgent inquiries, after-hours booking & support
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 flex gap-2">
              <a
                id="contact-emergency-call-btn"
                href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
                className="flex-1 py-2.5 rounded-xl bg-rose-600/30 hover:bg-rose-600 border border-rose-500/40 text-rose-200 hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call</span>
              </a>
              <a
                id="contact-emergency-wa-btn"
                href={createWhatsAppLink("Urgent Anjani Mobile Store Inquiry: ", true)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-rose-600/30"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-white" />
                <span>WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Card 4: ADDRESS */}
          <motion.div
            whileHover={{ y: -5 }}
            className="p-6 rounded-3xl bg-gradient-to-b from-[#1b1710] to-[#0e0c08] border border-amber-500/20 hover:border-amber-500/50 transition-all shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-amber-600/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-4">
                <MapPin className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                Showroom Location
              </span>
              <h3 className="text-xl font-bold text-white mt-1">ADDRESS</h3>
              <div className="text-xs text-neutral-300 mt-2 space-y-0.5 leading-relaxed">
                <p className="font-semibold text-white">Beltala Jayanagar Charali</p>
                <p>Khanapara Road</p>
                <p className="text-amber-300/90">Near Dalime Sweet, Opposite Wine Shop</p>
                <p>Ezzey Bazzar, Guwahati, Assam</p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
              <a
                id="contact-directions-btn"
                href={STORE_INFO.social.googleMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-500/20"
              >
                <Navigation className="w-4 h-4" />
                <span>GET DIRECTIONS</span>
              </a>
            </div>
          </motion.div>

        </div>

        {/* Full Interactive Google Maps Banner & Form */}
        <div className="rounded-3xl overflow-hidden border border-white/10 bg-[#0b0f19] p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-2xl">
          {/* Left Column: Direct Directions Trigger & Map Preview */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Clock className="w-4 h-4" />
              <span>Open All 7 Days: 10:00 AM - 9:30 PM</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-black text-white">
              Visit Our Showroom at <span className="gold-text-gradient">Ezzey Bazzar</span>
            </h3>

            <p className="text-sm text-neutral-300 leading-relaxed">
              Located conveniently at Beltala Jayanagar Charali on Khanapara Road, right near Dalime Sweet and opposite the wine shop inside Ezzey Bazzar. Ample parking and friendly staff await you.
            </p>

            {/* Large Prominent GET DIRECTIONS Button */}
            <div className="pt-2">
              <a
                id="contact-large-get-directions-btn"
                href={STORE_INFO.social.googleMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-black font-black text-sm sm:text-base shadow-[0_0_30px_rgba(245,158,11,0.35)] hover:shadow-[0_0_40px_rgba(245,158,11,0.5)] hover:scale-105 transition-all"
              >
                <Navigation className="w-5 h-5 fill-black" />
                <span>OPEN GOOGLE MAPS / GET DIRECTIONS</span>
              </a>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between text-xs text-neutral-300">
              <span>Google Maps Link:</span>
              <a
                href={STORE_INFO.social.googleMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-400 font-semibold hover:underline"
              >
                maps.app.goo.gl/xgT5mXD8KVHFNwy1A
              </a>
            </div>
          </div>

          {/* Right Column: Fast WhatsApp Message Composer */}
          <div className="lg:col-span-6 bg-black/40 p-6 rounded-2xl border border-white/10">
            <h4 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <Send className="w-4 h-4 text-emerald-400" />
              Quick Inquiry to Store Manager
            </h4>
            <p className="text-xs text-neutral-400 mb-5">
              Send your requirement directly to our official WhatsApp (+91 7002312833) with one click.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase text-neutral-400 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your name"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-neutral-500 focus:outline-none focus:border-amber-500/50"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase text-neutral-400 mb-1">
                    Mobile Number
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Your contact number"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-neutral-500 focus:outline-none focus:border-amber-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-neutral-400 mb-1">
                  I Want To:
                </label>
                <select
                  value={formData.interest}
                  onChange={(e) => setFormData({ ...formData, interest: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#111622] border border-white/10 text-white text-xs focus:outline-none focus:border-amber-500/50"
                >
                  <option value="Buy a Pre-Owned iPhone">Buy a Pre-Owned iPhone</option>
                  <option value="Buy an Android Phone">Buy an Android Phone</option>
                  <option value="Exchange My Old Phone">Exchange My Old Phone</option>
                  <option value="Sell My Phone for Cash">Sell My Phone for Cash</option>
                  <option value="Check Showroom Timings / Visit">Check Showroom Timings / Visit</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-neutral-400 mb-1">
                  Message or Specific Phone Model
                </label>
                <textarea
                  rows={2}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="e.g. Inquiring about iPhone 14 Pro 128GB or best deals under ₹20,000..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-neutral-500 focus:outline-none focus:border-amber-500/50 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Send WhatsApp Inquiry to Store</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
