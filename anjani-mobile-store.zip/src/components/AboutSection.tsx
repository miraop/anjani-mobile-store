import React, { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { ShieldCheck, Award, Users, ThumbsUp, Headset, MapPin, Youtube, Instagram, CheckCircle } from 'lucide-react';
import { STORE_INFO, STATS_DATA } from '../data/storeData';

// Counting component for upward counting numbers
const CounterNumber: React.FC<{ target: number; suffix: string }> = ({ target, suffix }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 2000;
    const stepTime = 30;
    const totalSteps = duration / stepTime;
    const increment = target / totalSteps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [isInView, target]);

  return (
    <span ref={ref} className="tabular-nums">
      {count.toLocaleString()}
      {suffix}
    </span>
  );
};

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="relative py-20 bg-[#070b14] overflow-hidden">
      {/* Ambient background decoration */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Guwahati's Verified Destination
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight"
          >
            ABOUT <span className="gold-text-gradient">ANJANI MOBILE STORE</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-base sm:text-lg text-neutral-300 leading-relaxed"
          >
            Founded on transparency, quality assurance, and unbeatable value, 
            <span className="text-white font-semibold"> ANJANI MOBILE STORE</span> is Guwahati’s trusted destination for buying, selling, and exchanging verified second-hand smartphones.
          </motion.p>
        </div>

        {/* Narrative & Visual Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-20">
          {/* Left Column: Visual Showcase Frame */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-6"
          >
            <div className="relative rounded-3xl p-3 bg-gradient-to-br from-neutral-800 to-neutral-900 border border-white/10 shadow-2xl">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-black">
                <img
                  src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop"
                  alt="Anjani Mobile Store smartphone showcase"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                
                {/* Overlay Badge */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white">
                  <div className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/15">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>Beltala Jayanagar Charali, Guwahati</span>
                  </div>
                  <div className="bg-emerald-600/90 backdrop-blur-md px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Verified Store
                  </div>
                </div>
              </div>

              {/* Floating Highlight Card */}
              <div className="absolute -bottom-6 -right-4 sm:right-6 bg-neutral-900/95 backdrop-blur-xl border border-amber-500/30 p-4 rounded-2xl shadow-xl max-w-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
                    <Award className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white">40-Point Diagnostic</p>
                    <p className="text-[11px] text-neutral-400">Zero duplicate parts. 100% legal device verification.</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Detailed Story */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-6 space-y-5"
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Where Guwahati Explores <span className="gold-text-gradient">Smarter Mobile Deals</span>
            </h3>

            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Buying a second-hand mobile should never feel like a gamble. At ANJANI MOBILE STORE, every pre-owned Apple iPhone, Samsung Galaxy, OnePlus, or budget Android smartphone undergoes rigorous diagnostic checks for battery health, display authenticity, camera modules, sensors, and network integrity.
            </p>

            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Whether you are upgrading to your dream flagship, looking for a reliable second device, or want instant cash for your existing mobile, our experienced team provides an open, honest, and comfortable environment right here at Ezzey Bazzar, Beltala.
            </p>

            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Legal Verification</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">Every device verified for authentic IMEI and clean history.</p>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center shrink-0 mt-0.5">
                  <Award className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Testing Warranty</h4>
                  <p className="text-[11px] text-neutral-400 mt-0.5">Peace of mind testing period so you can buy with total confidence.</p>
                </div>
              </div>
            </div>

            {/* Social channels preview */}
            <div className="pt-3 flex flex-wrap items-center gap-3">
              <a
                href={STORE_INFO.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-600/15 hover:bg-red-600/25 border border-red-500/30 text-red-300 text-xs font-semibold transition-all"
              >
                <Youtube className="w-4 h-4 text-red-500" />
                <span>YouTube: {STORE_INFO.social.youtubeHandle}</span>
              </a>

              <a
                href={STORE_INFO.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-pink-600/15 hover:bg-pink-600/25 border border-pink-500/30 text-pink-300 text-xs font-semibold transition-all"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span>Instagram: {STORE_INFO.social.instagramHandle}</span>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Animated Counter Stats Grid */}
        <div className="pt-8 border-t border-white/10">
          <div className="text-center mb-8">
            <h3 className="text-sm font-bold uppercase tracking-widest text-amber-400">
              Our Proven Track Record in Assam
            </h3>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {STATS_DATA.map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="p-6 rounded-2xl bg-gradient-to-b from-white/10 to-white/5 border border-white/10 hover:border-amber-500/30 transition-all text-center group"
              >
                <div className="text-3xl sm:text-4xl md:text-5xl font-black text-white group-hover:text-amber-400 transition-colors">
                  <CounterNumber target={stat.value} suffix={stat.suffix} />
                </div>
                <h4 className="mt-2 text-sm sm:text-base font-bold text-neutral-200">
                  {stat.label}
                </h4>
                <p className="mt-1 text-xs text-neutral-400">
                  {stat.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
