import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Store, Sparkles, MapPin, ExternalLink } from 'lucide-react';
import { STORE_ATMOSPHERE_SLIDER, STORE_INFO } from '../data/storeData';

export const ImageSliderSection: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIdx((prev) => (prev + 1) % STORE_ATMOSPHERE_SLIDER.length);
    }, 4500);
    return () => clearInterval(timer);
  }, []);

  const slide = STORE_ATMOSPHERE_SLIDER[currentIdx];

  return (
    <section className="py-20 bg-[#070b14] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-widest mb-3">
              <Store className="w-3.5 h-3.5" />
              Store Experience & Atmosphere
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
              INSIDE <span className="cyan-text-gradient">ANJANI MOBILE</span> STORE
            </h2>
            <p className="mt-2 text-sm sm:text-base text-neutral-300 max-w-2xl">
              Experience Guwahati's most modern pre-owned mobile destination. Transparent testing labs, hands-on flagship counters, and hassle-free instant exchanges.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              id="slider-visit-store-btn"
              href={STORE_INFO.social.googleMaps}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-semibold text-white flex items-center gap-2 transition-all"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>Get Directions to Beltala</span>
              <ExternalLink className="w-3 h-3 text-neutral-400" />
            </a>
          </div>
        </div>

        {/* Wide Slider Container */}
        <div className="relative rounded-3xl overflow-hidden aspect-[16/9] md:aspect-[21/9] border border-white/10 shadow-2xl bg-black">
          <AnimatePresence mode="wait">
            <motion.div
              key={slide.id}
              initial={{ opacity: 0, scale: 1.12 }}
              animate={{ opacity: 1, scale: 1.0 }}
              exit={{ opacity: 0, scale: 1.04 }}
              transition={{ duration: 1.2, ease: 'easeOut' }}
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${slide.image})` }}
            />
          </AnimatePresence>

          {/* Gradients */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-transparent to-transparent" />

          {/* Text Overlay */}
          <div className="absolute bottom-6 left-6 right-6 sm:bottom-10 sm:left-10 z-10 max-w-xl">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-amber-500/30">
              Showroom Atmosphere
            </span>
            <h3 className="text-xl sm:text-3xl font-black text-white mt-2">
              {slide.title}
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1.5 leading-relaxed">
              {slide.desc}
            </p>
          </div>

          {/* Slide Indicators on Bottom Right */}
          <div className="absolute bottom-6 right-6 sm:bottom-10 sm:right-10 z-10 flex items-center gap-2">
            {STORE_ATMOSPHERE_SLIDER.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIdx(idx)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  currentIdx === idx ? 'w-8 bg-amber-400' : 'w-2 bg-white/30'
                }`}
                aria-label={`Slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Left / Right Click Controls */}
          <button
            onClick={() => setCurrentIdx((prev) => (prev - 1 + STORE_ATMOSPHERE_SLIDER.length) % STORE_ATMOSPHERE_SLIDER.length)}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center transition-all"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            onClick={() => setCurrentIdx((prev) => (prev + 1) % STORE_ATMOSPHERE_SLIDER.length)}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center transition-all"
            aria-label="Next image"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
};
