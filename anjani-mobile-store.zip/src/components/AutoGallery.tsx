import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Sparkles, Eye, Play, Pause, MapPin } from 'lucide-react';
import { GALLERY_ITEMS, STORE_INFO, SAFE_IMAGE_FALLBACK } from '../data/storeData';

export const AutoGallery: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  // Auto-change every 3 seconds as strictly requested
  useEffect(() => {
    if (!isPlaying) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % GALLERY_ITEMS.length);
    }, 3000);
    return () => clearInterval(timer);
  }, [isPlaying]);

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % GALLERY_ITEMS.length);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length);
  };

  const currentItem = GALLERY_ITEMS[currentIndex];

  return (
    <section id="gallery" className="py-20 bg-[#050811] relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-amber-500/10 to-blue-600/10 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Flagship Presentation
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            PREMIUM <span className="gold-text-gradient">GALLERY</span> SHOWCASE
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            Immerse yourself in our cinematic showcase of verified smartphones, live device inspections, and genuine customer handovers in Beltala, Guwahati.
          </p>
        </div>

        {/* The Luxury Framed Presentation Screen */}
        <div className="max-w-4xl mx-auto">
          <div className="relative rounded-[32px] p-3 sm:p-4 bg-gradient-to-b from-neutral-700 via-neutral-900 to-neutral-950 border border-white/20 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_50px_rgba(245,158,11,0.15)] perspective-1000">
            {/* Ambient backlight glow */}
            <div className="absolute -inset-1 bg-gradient-to-r from-amber-500/30 via-cyan-500/20 to-purple-500/30 rounded-[34px] blur-xl opacity-60 pointer-events-none" />

            {/* Inner Metallic Display Screen Frame */}
            <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] rounded-[24px] overflow-hidden bg-black border border-white/10 shadow-inner flex items-center justify-center">
              
              {/* Dynamic 3-Second Auto-Transition Image */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentItem.id}
                  initial={{ opacity: 0, scale: 1.1, rotateX: 2 }}
                  animate={{ opacity: 1, scale: 1.0, rotateX: 0 }}
                  exit={{ opacity: 0, scale: 0.96, rotateX: -2 }}
                  transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${currentItem.image})` }}
                >
                  {/* Subtle sweep glare */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />
                  
                  {/* Bottom Vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                </motion.div>
              </AnimatePresence>

              {/* Floating Badge on Top Left */}
              <div className="absolute top-4 left-4 z-20">
                <motion.span
                  key={`badge-${currentIndex}`}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-amber-300 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  {currentItem.badge}
                </motion.span>
              </div>

              {/* Play / Pause Toggle Button on Top Right */}
              <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-2 rounded-xl bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white text-xs transition-all"
                  title={isPlaying ? 'Pause Auto Gallery (3s)' : 'Resume Auto Gallery (3s)'}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-emerald-400" />}
                </button>
              </div>

              {/* Bottom Information Overlay */}
              <div className="absolute bottom-4 left-4 right-4 z-20 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
                <div className="max-w-lg">
                  <motion.h3
                    key={`title-${currentIndex}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                    className="text-lg sm:text-2xl font-black text-white drop-shadow-md"
                  >
                    {currentItem.title}
                  </motion.h3>
                  <motion.p
                    key={`caption-${currentIndex}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.1 }}
                    className="text-xs sm:text-sm text-neutral-300 drop-shadow mt-0.5 line-clamp-2"
                  >
                    {currentItem.caption}
                  </motion.p>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-amber-400 bg-black/60 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10 shrink-0 self-start sm:self-auto">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Beltala, Guwahati</span>
                </div>
              </div>

              {/* Previous & Next Navigation Arrows */}
              <button
                id="gallery-prev-btn"
                onClick={prevImage}
                className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center transition-all hover:scale-110 active:scale-95"
                aria-label="Previous Gallery Item"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                id="gallery-next-btn"
                onClick={nextImage}
                className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/50 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white flex items-center justify-center transition-all hover:scale-110 active:scale-95"
                aria-label="Next Gallery Item"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Dots Indicator */}
          <div className="flex items-center justify-center gap-2 mt-5">
            {GALLERY_ITEMS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  currentIndex === idx
                    ? 'w-8 bg-amber-400'
                    : 'w-2 bg-white/25 hover:bg-white/50'
                }`}
                aria-label={`Jump to gallery image ${idx + 1}`}
              />
            ))}
          </div>

          {/* Thumbnails Row Below */}
          <div className="grid grid-cols-5 gap-2 sm:gap-3 mt-6">
            {GALLERY_ITEMS.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setCurrentIndex(idx)}
                className={`relative rounded-xl overflow-hidden aspect-[4/3] border transition-all duration-300 group ${
                  currentIndex === idx
                    ? 'border-amber-400 ring-2 ring-amber-400/40 scale-105 shadow-lg shadow-amber-500/20'
                    : 'border-white/10 opacity-60 hover:opacity-100 hover:border-white/30'
                }`}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    if (target.src !== SAFE_IMAGE_FALLBACK) {
                      target.src = SAFE_IMAGE_FALLBACK;
                    }
                  }}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
              </button>
            ))}
          </div>

          <p className="text-center text-[11px] text-neutral-400 mt-4">
            Images auto-advance every 3 seconds. Tap thumbnails or arrows to navigate instantly.
          </p>
        </div>
      </div>
    </section>
  );
};
