import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Phone, AlertCircle, ChevronLeft, ChevronRight, ShieldCheck, RefreshCw, BadgePercent, Sparkles } from 'lucide-react';
import { HERO_SLIDES, STORE_INFO, createWhatsAppLink, SAFE_IMAGE_FALLBACK } from '../data/storeData';

interface HeroSectionProps {
  onOpenInquiry: (topic?: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenInquiry }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [isPaused]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const slide = HERO_SLIDES[currentSlide];

  return (
    <section
      id="hero"
      className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background Cinematic Slider with Ken Burns Zoom & Fade Transitions */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, scale: 1.15 }}
            animate={{ opacity: 1, scale: 1.0 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${slide.image})` }}
          />
        </AnimatePresence>

        {/* Multi-layered cinematic gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#04060a] via-[#04060a]/85 to-[#04060a]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#04060a] via-transparent to-[#04060a]/70" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-[#04060a]/50 to-[#04060a]" />

        {/* Floating tech background aura */}
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Core Value Proposition & Headings */}
          <div className="lg:col-span-8 text-center lg:text-left">
            {/* Top pill badge */}
            <motion.div
              key={`badge-${currentSlide}`}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs sm:text-sm font-semibold mb-5 shadow-lg shadow-amber-500/10"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{slide.featuredBadge} • {slide.tag}</span>
            </motion.div>

            {/* Subheading: BUY • SELL • EXCHANGE */}
            <motion.h2
              key={`subheading-${currentSlide}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-amber-400 font-extrabold tracking-[0.25em] text-sm sm:text-base md:text-lg uppercase"
            >
              BUY • SELL • EXCHANGE
            </motion.h2>

            {/* Main Headline */}
            <motion.h1
              key={`headline-${currentSlide}`}
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="mt-2 text-3xl sm:text-5xl md:text-6xl xl:text-7xl font-black text-white tracking-tight leading-[1.08]"
            >
              PRE-OWNED SMARTPHONES AT <span className="gold-text-gradient">GREAT DEALS</span>
            </motion.h1>

            {/* Tagline */}
            <motion.p
              key={`tagline-${currentSlide}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.25 }}
              className="mt-4 text-base sm:text-lg md:text-xl font-medium text-neutral-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed"
            >
              QUALITY PHONES. TRUSTED SERVICE. BETTER VALUE.
            </motion.p>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-2 text-xs sm:text-sm text-neutral-400 max-w-xl mx-auto lg:mx-0"
            >
              Visit <span className="text-white font-semibold">ANJANI MOBILE STORE</span> at Beltala Jayanagar Charali, Guwahati. Explore certified iPhones, Samsung flagships, and premium Android phones with 40-point testing and verified checking warranty.
            </motion.p>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45, duration: 0.6 }}
              className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-3.5 sm:gap-4"
            >
              {/* 1. WhatsApp Us Button */}
              <a
                id="hero-whatsapp-btn"
                href={createWhatsAppLink("Hello Anjani Mobile Store! I am looking for a quality pre-owned phone. Please share today's available stock.")}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-6 sm:px-8 py-3.5 sm:py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-bold text-sm sm:text-base shadow-[0_10px_25px_-5px_rgba(16,185,129,0.5)] hover:shadow-[0_15px_30px_-5px_rgba(16,185,129,0.7)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2.5"
              >
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                  <MessageCircle className="w-4 h-4 fill-white" />
                </div>
                <span>WhatsApp Us</span>
                <span className="text-xs bg-black/20 px-2 py-0.5 rounded-full font-medium">Fast Reply</span>
              </a>

              {/* 2. Call Now Button */}
              <a
                id="hero-call-btn"
                href={`tel:${STORE_INFO.contacts.callClean}`}
                className="px-6 sm:px-7 py-3.5 sm:py-4 rounded-2xl bg-neutral-900/90 hover:bg-neutral-800 text-white border border-neutral-700 hover:border-amber-500/50 font-bold text-sm sm:text-base shadow-lg transition-all flex items-center gap-2.5 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Call Now: {STORE_INFO.contacts.call}</span>
              </a>

              {/* 3. Emergency Contact Button (Clearly visible but professionally designed) */}
              <a
                id="hero-emergency-btn"
                href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
                className="px-4 sm:px-5 py-3.5 sm:py-4 rounded-2xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 hover:text-rose-100 font-semibold text-xs sm:text-sm transition-all flex items-center gap-2 animate-emergency-pulse"
                title="Emergency Call & WhatsApp available 24/7"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Emergency Contact: {STORE_INFO.contacts.emergency}</span>
              </a>
            </motion.div>

            {/* Quick Trust Badges */}
            <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">40-Pt Checked</p>
                  <p className="text-[10px] text-neutral-400">100% Tested</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-4 h-4 text-blue-400" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Instant Exchange</p>
                  <p className="text-[10px] text-neutral-400">Top Trade Value</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
                  <BadgePercent className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Up to 60% Off</p>
                  <p className="text-[10px] text-neutral-400">vs Brand New</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-500/30 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Guwahati Hub</p>
                  <p className="text-[10px] text-neutral-400">Beltala Showroom</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Featured Deal Card with 3D Preview */}
          <div className="lg:col-span-4 flex flex-col items-center">
            <div className="relative w-full max-w-sm rounded-3xl p-5 bg-gradient-to-b from-white/10 to-white/5 backdrop-blur-xl border border-white/15 shadow-[0_20px_50px_rgba(0,0,0,0.6)] group">
              {/* Top tag */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/15 px-2.5 py-1 rounded-full border border-amber-500/30">
                  Today's Featured Deal
                </span>
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  In Stock Now
                </span>
              </div>

              {/* Image Preview with Glass Border */}
              <div className="relative h-60 rounded-2xl overflow-hidden mb-4 border border-white/10 bg-gradient-to-br from-[#141b2b] to-[#080c16]">
                <img
                  src={slide.image}
                  alt={slide.headline}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    if (target.src !== SAFE_IMAGE_FALLBACK) {
                      target.src = SAFE_IMAGE_FALLBACK;
                    }
                  }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#080d1a] via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <span className="text-xs font-bold text-white bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/15">
                    Flagship Certified
                  </span>
                  <span className="text-xs font-semibold text-amber-300 bg-amber-950/70 backdrop-blur-md px-2.5 py-1 rounded-lg border border-amber-500/30">
                    Beltala Store
                  </span>
                </div>
              </div>

              {/* Deal Details */}
              <h3 className="text-lg font-bold text-white leading-tight">
                {slide.headline}
              </h3>
              <p className="text-xs text-neutral-300 mt-1">
                {slide.subtext}
              </p>

              {/* Inquiry Action */}
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                <button
                  id="hero-check-deal-btn"
                  onClick={() => onOpenInquiry(`Deal inquiry: ${slide.headline}`)}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs shadow-md shadow-amber-500/20 transition-all text-center"
                >
                  Check Price on WhatsApp
                </button>
                <a
                  id="hero-direct-call-card-btn"
                  href={`tel:${STORE_INFO.contacts.callClean}`}
                  className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 transition-all"
                  title="Call Store"
                >
                  <Phone className="w-4 h-4 text-amber-400" />
                </a>
              </div>
            </div>

            {/* Slider Controls */}
            <div className="mt-4 flex items-center gap-3">
              <button
                onClick={prevSlide}
                className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-white transition-all"
                aria-label="Previous Slide"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2">
                {HERO_SLIDES.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentSlide(idx)}
                    className={`h-2 rounded-full transition-all ${
                      currentSlide === idx
                        ? 'w-7 bg-amber-400'
                        : 'w-2 bg-white/30 hover:bg-white/50'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={nextSlide}
                className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 flex items-center justify-center text-white transition-all"
                aria-label="Next Slide"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
