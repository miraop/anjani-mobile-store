import React from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  BadgePercent, 
  Coins, 
  ArrowLeftRight, 
  MessageSquare, 
  PhoneCall, 
  HeartHandshake,
  Sparkles,
  Check
} from 'lucide-react';
import { WHY_CHOOSE_US_POINTS, STORE_INFO } from '../data/storeData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-amber-400" />;
      case 'CheckCircle2':
        return <CheckCircle2 className="w-6 h-6 text-cyan-400" />;
      case 'BadgePercent':
        return <BadgePercent className="w-6 h-6 text-emerald-400" />;
      case 'Coins':
        return <Coins className="w-6 h-6 text-purple-400" />;
      case 'ArrowLeftRight':
        return <ArrowLeftRight className="w-6 h-6 text-pink-400" />;
      case 'MessageSquare':
        return <MessageSquare className="w-6 h-6 text-emerald-400" />;
      case 'PhoneCall':
        return <PhoneCall className="w-6 h-6 text-blue-400" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-6 h-6 text-amber-400" />;
      default:
        return <ShieldCheck className="w-6 h-6 text-amber-400" />;
    }
  };

  return (
    <section id="why-choose-us" className="py-20 bg-[#05070c] relative overflow-hidden">
      {/* Radial aura */}
      <div className="absolute top-1/2 left-1/3 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            The Anjani Advantage
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            WHY CHOOSE <span className="gold-text-gradient">ANJANI MOBILE STORE</span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            Guwahati's shoppers rely on us because we prioritize genuine quality checks, complete transparency, and customer satisfaction over quick sales.
          </p>
        </div>

        {/* 8 Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_CHOOSE_US_POINTS.map((point, idx) => (
            <motion.div
              key={point.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.07 }}
              whileHover={{ y: -6 }}
              className="p-6 rounded-3xl bg-gradient-to-b from-[#131a29] to-[#090d16] border border-white/10 hover:border-amber-500/40 transition-all duration-300 shadow-lg hover:shadow-[0_15px_30px_rgba(0,0,0,0.6)] flex flex-col justify-between group"
            >
              <div>
                {/* Icon Container with subtle gradient */}
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${point.color} border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  {getIcon(point.icon)}
                </div>

                <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold mb-1">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Guaranteed</span>
                </div>

                <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors leading-snug">
                  {point.title}
                </h3>

                <p className="mt-2 text-xs sm:text-sm text-neutral-400 leading-relaxed">
                  {point.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-400">
                <span>Verified in Guwahati</span>
                <span className="text-emerald-400 font-semibold">100% Trust</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
