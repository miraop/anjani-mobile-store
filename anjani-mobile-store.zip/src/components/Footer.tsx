import React from 'react';
import { Phone, MessageCircle, AlertCircle, MapPin, Youtube, Instagram, Navigation, ShieldCheck, Heart } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#03050a] border-t border-white/10 pt-16 pb-24 sm:pb-12 text-neutral-300 relative overflow-hidden">
      {/* Subtle top ambient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[1px] bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1 & 2: Brand Identity */}
          <div className="lg:col-span-2 space-y-4">
            <Logo size="lg" showTagline={true} />

            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed max-w-sm">
              Guwahati’s premier showroom for quality-checked, certified pre-owned smartphones. 
              Buy with testing warranty, sell for instant spot cash, or exchange with top market trade-in value.
            </p>

            <div className="pt-2 flex items-center gap-3">
              {/* YouTube */}
              <a
                id="footer-youtube-link"
                href={STORE_INFO.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-red-600 border border-white/10 flex items-center justify-center text-neutral-300 hover:text-white transition-all"
                aria-label="YouTube Channel"
              >
                <Youtube className="w-5 h-5" />
              </a>

              {/* Instagram */}
              <a
                id="footer-instagram-link"
                href={STORE_INFO.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-pink-600 border border-white/10 flex items-center justify-center text-neutral-300 hover:text-white transition-all"
                aria-label="Instagram Profile"
              >
                <Instagram className="w-5 h-5" />
              </a>

              {/* WhatsApp */}
              <a
                id="footer-whatsapp-link"
                href={createWhatsAppLink("Hi Anjani Mobile Store, I am contacting you from the footer of your website.")}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-emerald-600 border border-white/10 flex items-center justify-center text-neutral-300 hover:text-white transition-all"
                aria-label="WhatsApp Contact"
              >
                <MessageCircle className="w-5 h-5" />
              </a>

              {/* Google Maps Directions */}
              <a
                id="footer-maps-link"
                href={STORE_INFO.social.googleMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-amber-500 hover:text-black border border-white/10 flex items-center justify-center text-neutral-300 transition-all"
                aria-label="Google Maps Location"
              >
                <Navigation className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Col 3: Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#hero" className="hover:text-amber-400 transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="hover:text-amber-400 transition-colors">About Us</a>
              </li>
              <li>
                <a href="#mobiles" className="hover:text-amber-400 transition-colors">Mobiles</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-amber-400 transition-colors">Gallery</a>
              </li>
              <li>
                <a href="#why-choose-us" className="hover:text-amber-400 transition-colors">Why Choose Us</a>
              </li>
              <li>
                <a href="#sell-exchange" className="hover:text-amber-400 transition-colors">Sell & Exchange</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-400 transition-colors">Contact</a>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Numbers */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Contact Numbers
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm">
              <li>
                <p className="text-[10px] text-neutral-400 uppercase font-bold">WhatsApp</p>
                <a
                  href={createWhatsAppLink("Hi Anjani Mobile Store!")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-bold text-emerald-400 hover:underline flex items-center gap-1.5 mt-0.5"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  {STORE_INFO.contacts.whatsapp}
                </a>
              </li>
              <li>
                <p className="text-[10px] text-neutral-400 uppercase font-bold">Call Store</p>
                <a
                  href={`tel:${STORE_INFO.contacts.callClean}`}
                  className="font-bold text-blue-400 hover:underline flex items-center gap-1.5 mt-0.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  {STORE_INFO.contacts.call}
                </a>
              </li>
              <li>
                <p className="text-[10px] text-neutral-400 uppercase font-bold">Emergency 24/7</p>
                <a
                  href={`tel:${STORE_INFO.contacts.emergencyCallClean}`}
                  className="font-bold text-rose-400 hover:underline flex items-center gap-1.5 mt-0.5"
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  {STORE_INFO.contacts.emergency}
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Showroom Address & Timings */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-4">
              Store Location
            </h4>
            <div className="text-xs text-neutral-300 space-y-1 leading-relaxed">
              <p className="font-bold text-white">ANJANI MOBILE STORE</p>
              <p>Beltala Jayanagar Charali</p>
              <p>Khanapara Road</p>
              <p className="text-amber-400/90">Near Dalime Sweet, Opposite Wine Shop</p>
              <p>Ezzey Bazzar, Guwahati, Assam</p>
            </div>

            <div className="mt-4">
              <a
                id="footer-directions-btn"
                href={STORE_INFO.social.googleMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-all shadow-sm"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Directions</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <p>© {new Date().getFullYear()} ANJANI MOBILE STORE. All rights reserved.</p>
          <p className="flex items-center gap-1 text-[11px]">
            <span>Beltala, Guwahati, Assam</span>
            <span>•</span>
            <span className="text-neutral-400">Quality Certified Pre-Owned Phones</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
