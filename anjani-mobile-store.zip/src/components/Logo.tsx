import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  showTagline = true,
  className = '',
  onClick,
}) => {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-13 h-13',
    xl: 'w-16 h-16',
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-3 select-none cursor-pointer group ${className}`}
    >
      {/* Luxury Insignia Icon */}
      <div
        className={`relative ${iconSizes[size]} shrink-0 rounded-2xl p-[1.5px] bg-gradient-to-b from-amber-200 via-amber-500 to-amber-800 shadow-[0_4px_20px_rgba(245,158,11,0.35)] group-hover:shadow-[0_6px_25px_rgba(245,158,11,0.5)] transition-all duration-300 group-hover:scale-105`}
      >
        {/* Inner Dark Canvas with Radial Specular Highlight */}
        <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#141a29] via-[#090d16] to-[#04060a] p-1.5 flex items-center justify-center relative overflow-hidden">
          {/* Subtle gold glare line */}
          <div className="absolute -top-6 -left-6 w-12 h-12 bg-amber-400/25 rounded-full blur-md pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-400/15 via-transparent to-transparent pointer-events-none" />

          {/* Premium Geometric "A" + Smartphone Hybrid Vector Crest */}
          <svg
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)]"
          >
            <defs>
              {/* Gold Gradient */}
              <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFF2B2" />
                <stop offset="28%" stopColor="#F59E0B" />
                <stop offset="70%" stopColor="#D97706" />
                <stop offset="100%" stopColor="#92400E" />
              </linearGradient>

              {/* Platinum Accent Gradient */}
              <linearGradient id="platGradient" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#38BDF8" />
                <stop offset="100%" stopColor="#E0F2FE" />
              </linearGradient>

              {/* Glass Glaze */}
              <linearGradient id="shieldFill" x1="50%" y1="0%" x2="50%" y2="100%">
                <stop offset="0%" stopColor="#1E293B" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#0B0F19" stopOpacity="0.95" />
              </linearGradient>
            </defs>

            {/* Smartphone Outer Shell Contour with Rounded Corners */}
            <rect
              x="20"
              y="10"
              width="60"
              height="80"
              rx="16"
              stroke="url(#goldGradient)"
              strokeWidth="4"
              fill="url(#shieldFill)"
            />

            {/* Dynamic Camera Notch / Ear Speaker Bar */}
            <rect
              x="42"
              y="16"
              width="16"
              height="4"
              rx="2"
              fill="url(#goldGradient)"
            />
            <circle cx="61" cy="18" r="1.5" fill="#38BDF8" />

            {/* Faceted Monogram Letter "A" (Formed by Precision Angles) */}
            {/* Left Leg of A */}
            <path
              d="M 33 74 L 49 28 L 51 28 L 67 74 L 59 74 L 54 58 L 46 58 L 41 74 Z"
              fill="url(#goldGradient)"
            />

            {/* Modern Crossbar Cutout */}
            <path
              d="M 50 38 L 53 51 L 47 51 Z"
              fill="#080C14"
            />

            {/* Center Dynamic Sparkle / Core Diamond */}
            <polygon
              points="50,47 52,50 55,50 52.5,52 53.5,55 50,53 46.5,55 47.5,52 45,50 48,50"
              fill="#FFFFFF"
            />

            {/* Subtle Home Indicator Bar */}
            <rect
              x="40"
              y="83"
              width="20"
              height="2.5"
              rx="1.25"
              fill="url(#goldGradient)"
              opacity="0.8"
            />
          </svg>
        </div>
      </div>

      {/* Typography Section */}
      {showText && (
        <div className="flex flex-col leading-none">
          <div className="flex items-center gap-1.5">
            <span className="text-base sm:text-lg font-black tracking-tight text-white group-hover:text-amber-400 transition-colors uppercase font-['Outfit',sans-serif]">
              ANJANI
            </span>
            <span className="text-base sm:text-lg font-black tracking-tight text-amber-400 font-['Outfit',sans-serif]">
              MOBILE
            </span>
            <span className="text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded-md bg-gradient-to-r from-amber-500/25 to-amber-600/30 text-amber-300 font-extrabold border border-amber-500/40 uppercase tracking-wider shadow-sm">
              STORE
            </span>
          </div>

          {showTagline && (
            <div className="flex items-center gap-1 mt-1 text-[10px] text-neutral-400 tracking-wider">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-semibold text-neutral-300 uppercase tracking-widest text-[9px]">
                PRE-OWNED LUXURY
              </span>
              <span className="text-amber-500 font-bold">•</span>
              <span className="text-neutral-400 text-[9px]">GUWAHATI</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
