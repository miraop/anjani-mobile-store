import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageCircle, Phone, Sparkles, ShieldCheck, MapPin } from 'lucide-react';
import { STORE_INFO, createWhatsAppLink } from '../data/storeData';

interface InquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  phoneTopic?: string;
}

export const InquiryModal: React.FC<InquiryModalProps> = ({ isOpen, onClose, phoneTopic }) => {
  const [customNotes, setCustomNotes] = useState('');

  if (!isOpen) return null;

  const handleWhatsAppSend = () => {
    const text = `Hello Anjani Mobile Store! I am interested in: ${phoneTopic || 'available smartphone deals'}.
${customNotes ? `Note: ${customNotes}` : ''}
Please share current price, battery health, and availability at your Beltala, Guwahati showroom.`;
    window.open(createWhatsAppLink(text), '_blank');
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-lg rounded-3xl p-6 sm:p-8 bg-[#0e1320] border border-white/15 shadow-2xl text-white"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-all"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Header */}
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
            <Sparkles className="w-4 h-4" />
            Showroom Inquiry
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-white">
            Inquire About <span className="gold-text-gradient">{phoneTopic || 'Mobile Deals'}</span>
          </h3>

          <p className="text-xs sm:text-sm text-neutral-300 mt-2">
            Connect directly with ANJANI MOBILE STORE's team in Beltala, Guwahati. We will verify real-time showroom availability, battery health, and offer the best deal.
          </p>

          <div className="mt-4 p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5 text-xs text-neutral-300">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>40-Point Diagnostic Checked & Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Beltala Jayanagar Charali, Ezzey Bazzar, Guwahati</span>
            </div>
          </div>

          {/* Custom Requirement Input */}
          <div className="mt-5">
            <label className="block text-[11px] font-bold uppercase text-neutral-400 mb-1.5">
              Any specific storage, color, or trade-in requirement? (Optional)
            </label>
            <textarea
              rows={2}
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              placeholder="e.g. Need 256GB in pristine condition, or looking to exchange my iPhone 11..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs placeholder-neutral-500 focus:outline-none focus:border-amber-500/50 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleWhatsAppSend}
              className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Continue to WhatsApp</span>
            </button>

            <a
              href={`tel:${STORE_INFO.contacts.callClean}`}
              className="py-3.5 px-5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 text-blue-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all"
            >
              <Phone className="w-4 h-4 text-blue-400" />
              <span>Call Manager</span>
            </a>
          </div>

          <p className="mt-3 text-center text-[11px] text-neutral-400">
            WhatsApp: {STORE_INFO.contacts.whatsapp} • Call: {STORE_INFO.contacts.call}
          </p>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
