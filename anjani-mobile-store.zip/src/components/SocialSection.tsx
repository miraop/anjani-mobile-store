import React from 'react';
import { motion } from 'motion/react';
import { Youtube, Instagram, ExternalLink, Play, Sparkles, Heart, Bell } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';

export const SocialSection: React.FC = () => {
  return (
    <section id="social" className="py-20 bg-[#070b14] relative overflow-hidden">
      {/* Glows */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/2 right-1/4 w-96 h-96 bg-pink-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-400 text-xs font-bold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            Connect With Our Community
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight">
            FOLLOW US ON <span className="gold-text-gradient">SOCIAL MEDIA</span>
          </h2>

          <p className="mt-3 text-sm sm:text-base text-neutral-300">
            Watch live unboxings, customer delivery videos, price drop alerts, and new arrivals on our official YouTube and Instagram channels.
          </p>
        </div>

        {/* Social Cards: YouTube & Instagram */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* YouTube Channel Card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            className="rounded-3xl p-7 bg-gradient-to-b from-[#181a24] to-[#0c0e17] border border-red-500/20 hover:border-red-500/50 transition-all duration-300 shadow-xl shadow-red-950/20 flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="w-14 h-14 rounded-2xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500 group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all shadow-lg shadow-red-600/20">
                  <Youtube className="w-8 h-8" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-red-400 bg-red-500/15 px-3 py-1 rounded-full border border-red-500/30">
                  Official Channel
                </span>
              </div>

              <h3 className="text-2xl font-bold text-white group-hover:text-red-400 transition-colors">
                YouTube Channel
              </h3>
              <p className="text-sm font-semibold text-neutral-400 mt-1">
                {STORE_INFO.social.youtubeHandle}
              </p>

              <p className="mt-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                Watch full video reviews, smartphone camera comparisons, condition checks, and live deals directly from our showroom counter in Beltala, Guwahati.
              </p>

              {/* Video Perks Checklist */}
              <div className="mt-5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-neutral-300">
                  <Play className="w-3.5 h-3.5 text-red-400" />
                  <span>Real unboxing & testing videos</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-300">
                  <Bell className="w-3.5 h-3.5 text-red-400" />
                  <span>First notification on fresh stock arrival</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-white/10">
              <a
                id="youtube-channel-btn"
                href={STORE_INFO.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-red-600/30 transition-all group-hover:scale-[1.02]"
              >
                <Youtube className="w-5 h-5 fill-white" />
                <span>Visit & Subscribe to YouTube</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </motion.div>

          {/* Instagram Profile Card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -6 }}
            className="rounded-3xl p-7 bg-gradient-to-b from-[#1c1624] to-[#0d0a14] border border-pink-500/20 hover:border-pink-500/50 transition-all duration-300 shadow-xl shadow-pink-950/20 flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-white group-hover:scale-110 transition-all shadow-lg shadow-pink-500/30">
                  <Instagram className="w-7 h-7" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-pink-400 bg-pink-500/15 px-3 py-1 rounded-full border border-pink-500/30">
                  Daily Stories & Reels
                </span>
              </div>

              <h3 className="text-2xl font-bold text-white group-hover:text-pink-400 transition-colors">
                Instagram Page
              </h3>
              <p className="text-sm font-semibold text-neutral-400 mt-1">
                {STORE_INFO.social.instagramHandle}
              </p>

              <p className="mt-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                Follow our daily Instagram stories for flash sale prices, customer delivery moments, story Q&A, and direct messaging with our store staff.
              </p>

              {/* Instagram Perks Checklist */}
              <div className="mt-5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-neutral-300">
                  <Heart className="w-3.5 h-3.5 text-pink-400" />
                  <span>Real buyer handovers & reviews in Guwahati</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-300">
                  <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                  <span>24-hour exclusive story discounts</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-white/10">
              <a
                id="instagram-page-btn"
                href={STORE_INFO.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:opacity-90 text-white font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-pink-600/30 transition-all group-hover:scale-[1.02]"
              >
                <Instagram className="w-5 h-5" />
                <span>Follow on Instagram</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
