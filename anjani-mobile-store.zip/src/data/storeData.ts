export interface Product {
  id: string;
  name: string;
  brand: 'Apple' | 'Samsung' | 'OnePlus' | 'Google' | 'Other';
  category: string;
  condition: 'Like New (10/10)' | 'Flawless' | 'Excellent (9.5/10)' | 'Super Mint';
  storage: string;
  color: string;
  batteryHealth?: string;
  includes: string[];
  image: string;
  featured?: boolean;
  highlightTag?: string;
}

export interface StoreReview {
  id: string;
  name: string;
  location: string;
  rating: number;
  comment: string;
  phoneBought: string;
  date: string;
}

export const STORE_INFO = {
  name: 'ANJANI MOBILE STORE',
  tagline: 'PRE-OWNED MOBILES • BEST DEALS • TRUSTED STORE',
  subTagline: 'Guwahati\'s Most Trusted Hub for Buying, Selling & Exchanging Quality Pre-Owned Smartphones',
  
  address: {
    line1: 'Beltala Jayanagar Charali, Khanapara Road',
    landmark: 'Near Dalime Sweet, Opposite Wine Shop, Ezzey Bazzar',
    shop: 'Anjani Mobile Store',
    city: 'Guwahati',
    state: 'Assam',
    full: 'Beltala Jayanagar Charali, Khanapara Road, Near Dalime Sweet, Opposite Wine Shop, Ezzey Bazzar, Anjani Mobile Store, Guwahati, Assam'
  },
  
  contacts: {
    whatsapp: '+91 7002312833',
    whatsappClean: '917002312833',
    call: '+91 6900524178',
    callClean: '+916900524178',
    emergency: '+91 7099009971',
    emergencyClean: '917099009971',
    emergencyCallClean: '+917099009971'
  },
  
  social: {
    youtube: 'https://youtube.com/@anjanimobilestore9691',
    youtubeHandle: '@anjanimobilestore9691',
    instagram: 'https://instagram.com/anjani_mobile_store?igshid=MzRlODBiNWFlZA==',
    instagramHandle: '@anjani_mobile_store',
    googleMaps: 'https://maps.app.goo.gl/xgT5mXD8KVHFNwy1A?g_st=ic'
  },
  
  timing: {
    days: 'Monday - Sunday (All 7 Days)',
    hours: '10:00 AM - 9:30 PM'
  }
};

export const createWhatsAppLink = (message: string, isEmergency = false): string => {
  const number = isEmergency ? STORE_INFO.contacts.emergencyClean : STORE_INFO.contacts.whatsappClean;
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${number}?text=${encoded}`;
};

export const SAFE_IMAGE_FALLBACK = 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop';

export const HERO_SLIDES = [
  {
    id: 'hero-1',
    title: 'BUY • SELL • EXCHANGE',
    headline: 'PRE-OWNED SMARTPHONES AT GREAT DEALS',
    subtext: 'QUALITY PHONES. TRUSTED SERVICE. BETTER VALUE.',
    tag: 'Guwahati\'s Premier Mobile Hub',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1600&auto=format&fit=crop',
    featuredBadge: '100% Quality Checked'
  },
  {
    id: 'hero-2',
    title: 'FLAGSHIP IPHONES & ANDROIDS',
    headline: 'LUXURY PHONES AT FRACTION OF THE PRICE',
    subtext: 'Rigorous 40-Point Diagnostic Check on Every Single Device.',
    tag: 'Like-New Condition Guaranteed',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1600&auto=format&fit=crop',
    featuredBadge: '7-Day Testing Warranty'
  },
  {
    id: 'hero-3',
    title: 'INSTANT CASH & EXCHANGE',
    headline: 'UPGRADE YOUR PHONE IN 15 MINUTES',
    subtext: 'Bring your old phone, get top market valuation on the spot in Beltala.',
    tag: 'Best Exchange Value in Assam',
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=1600&auto=format&fit=crop',
    featuredBadge: 'Instant Valuation'
  }
];

export const CATEGORIES = [
  {
    id: 'cat-preowned',
    title: 'Pre-Owned Smartphones',
    desc: 'Certified pre-owned phones with complete hardware check and genuine parts verification.',
    icon: 'ShieldCheck',
    badge: 'Certified',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop',
    count: '35+ In Stock'
  },
  {
    id: 'cat-premium',
    title: 'Premium Smartphones',
    desc: 'Top-tier flagships from Apple Pro series and Samsung Ultra lineup at unbeatable prices.',
    icon: 'Sparkles',
    badge: 'Flagship',
    image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?q=80&w=800&auto=format&fit=crop',
    count: '15+ Available'
  },
  {
    id: 'cat-budget',
    title: 'Budget Smartphones',
    desc: 'High value daily drivers under ₹10,000 - ₹20,000 with long battery life & clear displays.',
    icon: 'Wallet',
    badge: 'Value Picks',
    image: 'https://images.unsplash.com/photo-1567581935884-3349723552ca?q=80&w=800&auto=format&fit=crop',
    count: '25+ In Stock'
  },
  {
    id: 'cat-iphones',
    title: 'iPhones Collection',
    desc: 'From iPhone 11 to 15 Pro Max. High battery health, TrueTone enabled, clean serials.',
    icon: 'Smartphone',
    badge: 'Apple',
    image: 'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?q=80&w=800&auto=format&fit=crop',
    count: '20+ Models'
  },
  {
    id: 'cat-android',
    title: 'Android Phones',
    desc: 'Samsung, OnePlus, Vivo, Oppo, Realme, Xiaomi & Google Pixel devices ready to test.',
    icon: 'Cpu',
    badge: 'Android',
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=800&auto=format&fit=crop',
    count: '40+ Models'
  },
  {
    id: 'cat-exchange',
    title: 'Mobile Exchange',
    desc: 'Trade in your old smartphone for an instant discount on your dream upgrade.',
    icon: 'Repeat',
    badge: 'Best Trade-In',
    image: 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?q=80&w=800&auto=format&fit=crop',
    count: 'Instant Deal'
  },
  {
    id: 'cat-buyused',
    title: 'Buy Used Phones',
    desc: 'Browse our tested stock with original bill/box availability and transparent grading.',
    icon: 'CheckCircle2',
    badge: 'Verified',
    image: 'https://images.unsplash.com/photo-1585060544812-6b45742d762f?q=80&w=800&auto=format&fit=crop',
    count: 'Transparent'
  },
  {
    id: 'cat-sellmobile',
    title: 'Sell Your Mobile',
    desc: 'Get instant cash payment for your used mobile phone. Highest buyout price in Guwahati.',
    icon: 'Banknote',
    badge: 'Instant Cash',
    image: 'https://images.unsplash.com/photo-1591337676887-a217a6970a8a?q=80&w=800&auto=format&fit=crop',
    count: 'Spot Payment'
  }
];

export const FEATURED_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Apple iPhone 15 Pro',
    brand: 'Apple',
    category: 'iPhones',
    condition: 'Like New (10/10)',
    storage: '256GB',
    color: 'Natural Titanium',
    batteryHealth: '98% Battery Health',
    includes: ['Original Box', 'Braided Type-C Cable', 'Store Bill with Warranty'],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=800&auto=format&fit=crop',
    featured: true,
    highlightTag: 'Hot Seller'
  },
  {
    id: 'prod-2',
    name: 'Samsung Galaxy S23 Ultra 5G',
    brand: 'Samsung',
    category: 'Android Phones',
    condition: 'Super Mint',
    storage: '256GB / 12GB RAM',
    color: 'Phantom Black',
    batteryHealth: 'Excellent Battery Life',
    includes: ['Original S-Pen', 'Super Fast 45W Ready', 'Store Warranty'],
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=800&auto=format&fit=crop',
    featured: true,
    highlightTag: 'Camera King'
  },
  {
    id: 'prod-3',
    name: 'Apple iPhone 14 Pro Max',
    brand: 'Apple',
    category: 'iPhones',
    condition: 'Flawless',
    storage: '128GB',
    color: 'Deep Purple',
    batteryHealth: '94% Battery Health',
    includes: ['Original Box', 'Charging Cable', 'Screen Guard Applied'],
    image: 'https://images.unsplash.com/photo-1678685888221-cda773a3dcdb?q=80&w=800&auto=format&fit=crop',
    featured: true,
    highlightTag: 'Top Pick'
  },
  {
    id: 'prod-4',
    name: 'OnePlus 11 5G',
    brand: 'OnePlus',
    category: 'Android Phones',
    condition: 'Like New (10/10)',
    storage: '256GB / 16GB RAM',
    color: 'Eternal Green',
    batteryHealth: 'Superb 5000mAh',
    includes: ['100W SUPERVOOC Charger', 'Original Box', 'Protective Case'],
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=800&auto=format&fit=crop',
    featured: true,
    highlightTag: 'Fast Performance'
  },
  {
    id: 'prod-5',
    name: 'Google Pixel 7 Pro',
    brand: 'Google',
    category: 'Android Phones',
    condition: 'Excellent (9.5/10)',
    storage: '128GB',
    color: 'Hazel & Gold',
    batteryHealth: 'Clean Pure Battery',
    includes: ['USB-C Cable', 'Store Verification Receipt'],
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=800&auto=format&fit=crop',
    featured: false,
    highlightTag: 'Pure Android'
  },
  {
    id: 'prod-6',
    name: 'Apple iPhone 13',
    brand: 'Apple',
    category: 'iPhones',
    condition: 'Super Mint',
    storage: '128GB',
    color: 'Midnight Blue',
    batteryHealth: '89% Battery Health',
    includes: ['Original Box', 'Cable', 'Testing Warranty'],
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop',
    featured: true,
    highlightTag: 'Best Value iPhone'
  }
];

export const GALLERY_ITEMS = [
  {
    id: 'gal-1',
    title: 'Flagship iPhone Collection',
    caption: 'Every device inspected for pristine aesthetics & 100% genuine Apple components.',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop',
    badge: 'Apple Flagships'
  },
  {
    id: 'gal-2',
    title: 'Samsung Galaxy Ultra Series',
    caption: 'Ultra zooms, flawless displays, and S-Pen ready phones available in store.',
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=1200&auto=format&fit=crop',
    badge: 'Galaxy Lineup'
  },
  {
    id: 'gal-3',
    title: 'Hands-On Device Testing',
    caption: 'Customers can touch, inspect, camera-test, and run benchmarks before making any decision.',
    image: 'https://images.unsplash.com/photo-1567581935884-3349723552ca?q=80&w=1200&auto=format&fit=crop',
    badge: 'Live Testing'
  },
  {
    id: 'gal-4',
    title: 'Verified Packaging & Accessories',
    caption: 'We provide genuine chargers, protective tempered glass, and warranty slips.',
    image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?q=80&w=1200&auto=format&fit=crop',
    badge: 'Accessories'
  },
  {
    id: 'gal-5',
    title: 'Happy Customer Handover in Guwahati',
    caption: 'Hundreds of tech lovers across Assam trust Anjani Mobile Store for honest deals.',
    image: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?q=80&w=1200&auto=format&fit=crop',
    badge: 'Customer Smiles'
  }
];

export const STORE_ATMOSPHERE_SLIDER = [
  {
    id: 'slide-1',
    title: 'Modern Tech Showroom in Beltala',
    desc: 'Located at Ezzey Bazzar, Beltala Jayanagar Charali with a clean, welcoming ambiance.',
    image: 'https://images.unsplash.com/photo-1567581935884-3349723552ca?q=80&w=1200&auto=format&fit=crop'
  },
  {
    id: 'slide-2',
    title: '40-Point Hardware & Battery Lab Check',
    desc: 'Each smartphone is verified for display original touch, camera stabilization, mic, and battery health.',
    image: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=1200&auto=format&fit=crop'
  },
  {
    id: 'slide-3',
    title: 'Live Device Demos & Comparison',
    desc: 'Compare cameras, form factors, and storage variants side-by-side with our friendly mobile experts.',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop'
  },
  {
    id: 'slide-4',
    title: 'Instant Cash for Old Phones',
    desc: 'Walk in with your old device and leave with instant cash or a shiny upgrade in under 15 minutes.',
    image: 'https://images.unsplash.com/photo-1591337676887-a217a6970a8a?q=80&w=1200&auto=format&fit=crop'
  }
];

export const WHY_CHOOSE_US_POINTS = [
  {
    title: 'Trusted Second-Hand Mobile Store',
    desc: 'Proudly serving Guwahati with 100% genuine, legal, bill-verified smartphones with zero blacklisted devices.',
    icon: 'ShieldCheck',
    color: 'from-amber-500/20 to-amber-600/5'
  },
  {
    title: 'Quality Checked Devices',
    desc: 'Strict 40-point diagnostic inspection covering battery health, motherboard, cameras, sensors, and original screens.',
    icon: 'CheckCircle2',
    color: 'from-cyan-500/20 to-blue-600/5'
  },
  {
    title: 'Affordable Deals',
    desc: 'Save up to 40% to 60% compared to brand new retail prices while getting flagship performance.',
    icon: 'BadgePercent',
    color: 'from-emerald-500/20 to-teal-600/5'
  },
  {
    title: 'Mobile Buying & Selling',
    desc: 'Whether you want to buy a pre-owned phone or sell your old handset for instant money, we offer transparent valuation.',
    icon: 'Coins',
    color: 'from-purple-500/20 to-indigo-600/5'
  },
  {
    title: 'Mobile Exchange Options',
    desc: 'Hassle-free trade-ins. Upgrade your current phone to a higher model and only pay the difference.',
    icon: 'ArrowLeftRight',
    color: 'from-pink-500/20 to-rose-600/5'
  },
  {
    title: 'WhatsApp Support',
    desc: 'Get fast photos, live video inspection of any phone in stock, and price quotes directly on WhatsApp.',
    icon: 'MessageSquare',
    color: 'from-emerald-500/20 to-green-600/5'
  },
  {
    title: 'Easy Contact',
    desc: 'Dedicated phone lines, WhatsApp numbers, and an emergency contact line for immediate assistance.',
    icon: 'PhoneCall',
    color: 'from-blue-500/20 to-sky-600/5'
  },
  {
    title: 'Customer-Friendly Service',
    desc: 'No pushy sales. Friendly tech advice, free data transfer assistance, and post-purchase support.',
    icon: 'HeartHandshake',
    color: 'from-amber-500/20 to-orange-600/5'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    step: '01',
    title: 'Choose Your Mobile',
    desc: 'Explore our verified catalog online or visit our showroom in Beltala. Select the model, color, and storage that fits your budget.',
    action: 'Browse Mobiles'
  },
  {
    step: '02',
    title: 'Contact Us on WhatsApp or Call',
    desc: 'Tap WhatsApp (+91 7002312833) or Call (+91 6900524178). We share live device photos, battery report, and finalize your deal.',
    action: 'Chat on WhatsApp'
  },
  {
    step: '03',
    title: 'Get the Best Deal',
    desc: 'Walk into Anjani Mobile Store at Ezzey Bazzar or get express delivery across Guwahati with easy payment options.',
    action: 'Collect & Enjoy'
  }
];

export const STATS_DATA = [
  { label: 'Trusted Customers', value: 5000, suffix: '+', desc: 'Satisfied buyers in Guwahati & Assam' },
  { label: 'Mobile Deals Done', value: 12500, suffix: '+', desc: 'Successful purchases and trade-ins' },
  { label: 'Happy Buyers', value: 99, suffix: '%', desc: 'Positive rating and repeat customers' },
  { label: 'Customer Support', value: 24, suffix: '/7', desc: 'Quick WhatsApp & Call responsiveness' }
];
